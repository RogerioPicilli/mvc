<?php
define("ENVIRONMENT", "development");
//define("ENVIRONMENT", "production");